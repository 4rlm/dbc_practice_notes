# Octopus Biography

* Name: Ollie
* Age: 8

### Clothing Style

* Cowboy Hat
* Heart-shaped glasses
