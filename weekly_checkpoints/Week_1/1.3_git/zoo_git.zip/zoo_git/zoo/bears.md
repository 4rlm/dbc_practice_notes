# Bears

### Bear Names:
* Billy Bear
* Barbie Bear
* Bobbie Bear
* Brittney Bear

```html
<div>
    <h1>Bears</h1>
    <h3>Bear Names</h3>

    <ul>
        <li>Billy Bear</li>
        <li>Barbie Bear</li>
        <li>Bobbie Bear</li>
        <li>Brittney Bear</li>
    </ul>
</div>
```
